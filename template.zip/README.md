# Bopl Lua Template

Welcome to the **Bopl Lua Template**!

## Getting Started

To view this document in Markdown format, press `Ctrl + Shift + V`.

## Documentation

For documentation and resources, please visit: [Map Maker Lua Documentation](https://map-maker.abstractmelon.net/docs/lua/)

## Enjoy Your Mapping Journey!

Happy map making! If you have any questions or need assistance, feel free to reach out on [Discord](https://discord.gg/Fpbg8MpKnm)
